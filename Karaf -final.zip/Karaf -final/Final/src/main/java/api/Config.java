package api;

public class Config {
	private String cKey;
	private String cSecret;
	private String aToken;
	private String aSecret;
	
	public String getcKey() {
		return cKey;
	}
	public void setcKey(String cKey) {
		this.cKey = cKey;
	}
	public String getcSecret() {
		return cSecret;
	}
	public void setcSecret(String cSecret) {
		this.cSecret = cSecret;
	}
	public String getaToken() {
		return aToken;
	}
	public void setaToken(String aToken) {
		this.aToken = aToken;
	}
	public String getaSecret() {
		return aSecret;
	}
	public void setaSecret(String aSecret) {
		this.aSecret = aSecret;
	}
	
	
}
